﻿using Datos;
using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logica
{
    public class LogicaDatosCarne : ControldeDatos<Carne>
    {
        List<Carne> carnes;
        RepositoioCarne Repositorio_carne;
        public LogicaDatosCarne()
        {
            Repositorio_carne = new RepositoioCarne("Carne.txt");
            carnes = Repositorio_carne.GetAll();
        }
        public string Delete(Carne Carne)
        {
            throw new NotImplementedException();
        }

        public string Edit(Carne oldCarne, Carne UpdateCarne)
        {
            throw new NotImplementedException();
        }

        public bool Exists(Carne Carne)
        {
            throw new NotImplementedException();
        }

        public List<Carne> GetAll()
        {
            return Repositorio_carne.GetAll();
        }

        public Carne GetById(int id)
        {
            throw new NotImplementedException();
        }

        public Carne GetByPhone(string phone)
        {
            throw new NotImplementedException();
        }

        public string Save(Carne carne)
        {
            Repositorio_carne.Guardar(carne);
            carnes = Repositorio_carne.GetAll();
            return $"Carne registrada con el nombre : {carne.NombreCarne1}";
        }
       
    }
}
