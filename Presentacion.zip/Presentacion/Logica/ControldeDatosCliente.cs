﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Logica
{
    public interface ControldeDatosCliente<T>
    {

        string Save(T Cliente);
        string Delete(T Cliente);
        string Edit(T oldCliente, T UpdateCliente);
        List<T> GetAll();
        T GetById(int id);
        T GetByPhone(string phone);
        bool Exists(T Cliente);

    }
}