﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades;
using Datos;

namespace Logica
{
    public class LogicaDatosCliente : ControldeDatos<Cliente>
    {
        List<Cliente> clientes;
        RepositorioCliente Repositorio_cliente;

        public LogicaDatosCliente()
        {
            Repositorio_cliente = new RepositorioCliente("Cliente.txt");
            clientes = Repositorio_cliente.GetAll();
        }

        public void Refresh()
        {
            clientes = Repositorio_cliente.GetAll();
        }

        public string Save(Cliente cliente)
        {
            Repositorio_cliente.Guardar(cliente);
            clientes = Repositorio_cliente.GetAll();
            return $"Cliente creado con el nombre : {cliente.Nombre}";
        }

        public string Delete(Cliente cliente)
        {

            var Telefono = GetByPhone(cliente.Telefono);
            clientes.Remove(Telefono);
            Repositorio_cliente.Update(clientes);
            Refresh();
            return $"El contacto se elimino correctamente con el nombre de {cliente.Nombre}";
            
        }

        public string Edit(Cliente oldCliente, Cliente UpdateCliente)
        {
            oldCliente.Id = UpdateCliente.Id;
            oldCliente.Nombre = UpdateCliente.Nombre;
            oldCliente.Telefono = UpdateCliente.Telefono;
            var estado = Repositorio_cliente.Update(clientes);
            Refresh();
            return estado ? $"se actulizo el cliente {UpdateCliente.Nombre}" : 
                            $"ERROR al actulizar los datos del cliente {UpdateCliente.Nombre}";


        }

        public bool Exists(Cliente cliente)
        {
            throw new NotImplementedException();
        }

        public List<Cliente> GetAll()
        {
            return Repositorio_cliente.GetAll();
        }

        public Cliente GetById(int id)
        {
            foreach (var item in clientes)
            {
                if (id == item.Id)
                {
                    return item;
                }
            }
            return null;
        }

        public Cliente GetByPhone(string phone)
        {
            foreach (var item in clientes)
            {
                if(item.Telefono == phone)
                {
                    Console.WriteLine(item);
                    return item;
                }
            }
            return null;
        }

        public Cliente GetByTodos(string value)
        {
            foreach (var item in clientes)
            {
                if (item.Nombre.Equals(value) || item.Telefono.Equals(value))
                {
                    return item;
                }
            }
            return null;
        }
    }
}