﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Factura : Persona
    {
       
        private string Id_Compra = "";
        private string Tipo_Carne = "";
        private string Precio = "";
        private string Cantidad = "";
        private string Sub_Total = "";
        private string Total = "";

            public string Id_Compra1 { get => Id_Compra; set => Id_Compra = value; }
            public string Tipo_Carne1 { get => Tipo_Carne; set => Tipo_Carne = value; }
            public string Precio1 { get => Precio; set => Precio = value; }
            public string Cantidad1 { get => Cantidad; set => Cantidad = value; }
            public string Sub_Total1 { get => Sub_Total; set => Sub_Total = value; }
            public string Total1 { get => Total; set => Total = value; }


        public override string ToString()
        {
            return $"{Id_Compra1};{Tipo_Carne1};{Precio1};{Cantidad1};{Sub_Total1};{Total1}";
        }
    }
}
