﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class Carne: Persona
    {
        private string NombreCarne = "";

        public string NombreCarne1 { get => NombreCarne; set => NombreCarne = value; }

        public override string ToString()
        {
            return $"{NombreCarne}";
        }
    }
}
