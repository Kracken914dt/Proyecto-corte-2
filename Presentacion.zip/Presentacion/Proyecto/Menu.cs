﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentacion
{
    public class Menu
    {

        //public void MenuPrincipal()
        //{
        //    int op;
        //    do
        //    {

        //        Console.WriteLine("Agenda");
        //        Console.WriteLine("1. Agregar contacto");
        //        Console.WriteLine("2. Ver lista de contactos");
        //        Console.WriteLine("3. Buscar contacto");
        //        Console.WriteLine("4. Modificar contacto");
        //        Console.WriteLine("5. Eliminar contacto");
        //        Console.WriteLine("6. Salir");
        //        op = int.Parse(Console.ReadLine());

        //        switch (op)
        //        {
        //            case 1:
        //                new MenuAgregar().EjecutarAgregar();
        //                break;

        //            case 2:
        //                new MostrarTodos().Todos();
        //                break;

        //            case 3:
        //                new Buscar().BuscarTel();
        //                break;

        //            case 4:
        //                new Editar().EditarContacto();
        //                break;

        //            case 5:
        //                new EliminarMenu().EliminarContacto();
        //                break;
        //        }

        //    } while (op != 6);
        //}

    }
}
