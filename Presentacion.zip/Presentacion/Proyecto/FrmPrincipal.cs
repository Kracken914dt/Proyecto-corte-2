﻿using PresentacionGUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
            personalizarDiseño();
        }
        private void personalizarDiseño()
        {
            panel1.Visible = false;
            panel2.Visible = false;

        }
        private void hideSubmenu()
        {
            if (panel1.Visible == true)
                panel1.Visible = false;
            if (panel2.Visible == true)
                panel2.Visible = false;
   
        }
        private void showMenu(Panel Submenu)
        {
            if (Submenu.Visible == false)
            {
                hideSubmenu();
                Submenu.Visible = true;
            }
            else
                Submenu.Visible = false;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            showMenu(panel1);
        }

        private void btnUsuario_Click(object sender, EventArgs e)
        {
            //falta invocar el menu de agregar datos usuario
            var usuario = new FrmDatosUsuario ();
            usuario.ShowDialog();
            hideSubmenu();
        }

        private void btnCompra_Click(object sender, EventArgs e)
        {
            //falta invocar el menu de agregar datos compra
            var compra = new FrmDatosCompra ();
            compra.ShowDialog();
            hideSubmenu();
        }

        private void btnNegocio_Click(object sender, EventArgs e)
        {
            showMenu (panel2);
        }

       

        private void btnGestion_Click(object sender, EventArgs e)
        {
            var login = new FrmLogin();
            login.ShowDialog();
            hideSubmenu ();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var verDatosUser = new FormTodosClientes();
            verDatosUser.ShowDialog();
            hideSubmenu();
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
}
