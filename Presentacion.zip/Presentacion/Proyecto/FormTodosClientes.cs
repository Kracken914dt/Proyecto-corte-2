﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using Logica;

namespace PresentacionGUI
{
    public partial class FormTodosClientes : Form
    {
        LogicaDatosCliente servicioCliente = new LogicaDatosCliente();

        public FormTodosClientes()
        {
            InitializeComponent();
            CargarGrilla();
        }


        void CargarGrilla()
        {
            foreach (var item in servicioCliente.GetAll())
            {
                GrillaFamiliar.Rows.Add(item.Id, item.Nombre, item.Telefono);
            }
        }

        private void FormTodosFamiliar_Load(object sender, EventArgs e)
        {

        }

        int fila;
        private void GrillaFamiliar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void GrillaFamiliar_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            Editar();

        }

        FormEditarCliente EditarCliente = new FormEditarCliente();
        public void Editar()
        {
            EditarCliente.txtId.Text = GrillaFamiliar.CurrentRow.Cells[0].Value.ToString();
            EditarCliente.txtNombre.Text = GrillaFamiliar.CurrentRow.Cells[1].Value.ToString();
            EditarCliente.txtTelefono.Text = GrillaFamiliar.CurrentRow.Cells[2].Value.ToString();
            EditarCliente.ShowDialog();
            Refrescar();
        }


        public void Refrescar()
        {
            GrillaFamiliar.Rows.Clear();
            GrillaFamiliar.Refresh();
            CargarGrilla();

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            EliminarGeneral();
        }

        public void EliminarGeneral() 
        {
            var pregunta = MessageBox.Show("¿Esta seguro de eliminar: " + GrillaFamiliar.CurrentRow.Cells[1].Value.ToString() + "?", "Eliminar Cliente", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            var cliente = new Cliente();
            cliente.Telefono = GrillaFamiliar.Rows[fila].Cells[2].Value.ToString();
            if (pregunta == DialogResult.Yes)
            {
                Eliminar(cliente);
                Refrescar();
                fila = 0;
            }
        }

        void Eliminar(Cliente cliente)
        {
            var mensaje = servicioCliente.Delete(cliente);
            MessageBox.Show(mensaje);
        }

        private void GrillaFamiliar_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            fila = e.RowIndex;
        }

        private void GrillaFamiliar_MouseClick(object sender, MouseEventArgs e)
        {
            //MouseClicDerecho(e);
        }
        private void Editar(Object sender, EventArgs e)
        {
            Editar();
        }
        private void CleanSelected(Object sender, EventArgs e)
        {
            EliminarGeneral();
        }

        public void MouseClicDerecho(MouseEventArgs e)
        {

        }

        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            switch (e.ClickedItem.Name)
            {
                case "Editar":

                    break;
                case "Eliminar":

                    break;

            }

        }

        private void GrillaFamiliar_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && e.RowIndex > -1)
            {
                foreach(DataGridViewRow dr in GrillaFamiliar.SelectedRows)
                {
                    dr.Selected = false;
                }

                GrillaFamiliar.Rows[e.RowIndex].Selected = true;
                ContextMenu cm = new ContextMenu();
                MenuItem mi = new MenuItem();
                mi.Text = "Editar";
                mi.Click += Editar; //metodo al dar cl
                                    //ick
                cm.MenuItems.Add(mi);

                mi = new MenuItem();
                mi.Text = "Eliminar";
                mi.Click += CleanSelected; //metodo al dar click
                cm.MenuItems.Add(mi);

                cm.Show(GrillaFamiliar, new Point(this.Left + GrillaFamiliar.Left + e.X, this.Top + GrillaFamiliar.Top + e.Y));
            }
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

