﻿using Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class RepositoioCarne : Archivo
    {
        public RepositoioCarne() : base()
        {

        }
        public RepositoioCarne(string fileName) : base(fileName)
        {

        }
        public List<Carne> GetAll()
        {
            try
            {
                StreamReader sr = new StreamReader(ruta);
                List<Carne> carnes = new List<Carne>();
                while (!sr.EndOfStream)
                {
                    carnes.Add(Mappear(sr.ReadLine()));
                }
                sr.Close();
                return carnes;
            }
            catch (Exception)
            {

                return null;
            }

        }

        Carne Mappear(string lineaDatos)
        {
            var carne = new Carne();
            carne.NombreCarne1 = (lineaDatos.Split(';')[0]);
            return carne;
        }

        public bool Update(List<Carne> carnes)
        {
            try
            {
                var sw = new StreamWriter(ruta, false);
                foreach (var item in carnes)
                {
                    sw.WriteLine(item.ToString());
                }

                sw.Close();

                return true;
            }
            catch (Exception)
            {
                return false;

            }

        }
    }
}
