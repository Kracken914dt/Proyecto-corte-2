﻿using Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class RepositorioRecibo : Archivo
    {
        public RepositorioRecibo() : base()
        {

        }
        public RepositorioRecibo(string fileName):base(fileName)
        {

        }
        public List<Factura> GetAll()
        {
            try
            {
                StreamReader sr = new StreamReader(ruta);
                List<Factura> factura = new List<Factura>();
                while (!sr.EndOfStream)
                {
                    factura.Add(Mappear(sr.ReadLine()));
                }
                sr.Close();
                return factura;
            }
            catch (Exception)
            {

                return null;
            }

        }

        Factura Mappear(string lineaDatos)
        {
            var facturas = new Factura();

            facturas.Id_Compra1 = (lineaDatos.Split(';')[0]);
            facturas.Tipo_Carne1 = (lineaDatos.Split(';')[1]);
            facturas.Precio1 = (lineaDatos.Split(';')[2]);
            facturas.Cantidad1 = (lineaDatos.Split(';')[3]);
            facturas.Sub_Total1 = (lineaDatos.Split(';')[4]);
            facturas.Total1 = (lineaDatos.Split(';')[5]);
            return facturas;
        }

        public bool Update(List<Factura> facturas)
        {
            try
            {
                var sw = new StreamWriter(ruta, false);
                foreach (var item in facturas)
                {
                    sw.WriteLine(item.ToString());
                }

                sw.Close();

                return true;
            }
            catch (Exception)
            {
                return false;

            }
        }

    }
}
