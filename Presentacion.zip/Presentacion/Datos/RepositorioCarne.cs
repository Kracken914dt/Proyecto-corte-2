﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
namespace Datos
{
    public class RepositorioCarne : Archivo
    {
        public RepositorioCarne() : base()
        {

        }
        public RepositorioCarne(string fileName) : base(fileName)
        {

        }
        public List<Carne> GetAll()
        {
            StreamReader sr = new StreamReader(ruta);
            //string linea;
            List<Carne> carnes = new List<Carne>();
            while (!sr.EndOfStream)
            {
                //linea = sr.ReadLine();
                carnes.Add(Mappear(sr.ReadLine()));
            }
            sr.Close();
            return carnes;
        }
        Carne Mappear(string lineaDatos)
        {
            var carne = new Entidades.Carne();

            carne.TipoCarne = (lineaDatos.Split(';')[0]);
            carne.Animal = (lineaDatos.Split(';')[1]);
            return carne;
        }

        public bool Update(List<Carne> carne)
        {
            try
            {
                var sw = new StreamWriter(ruta, false);
                foreach (var item in carne)
                {
                    sw.WriteLine(item.ToString());
                }

                sw.Close();

                return true;
            }
            catch (Exception)
            {
                return false;

            }

        }
    }
}
